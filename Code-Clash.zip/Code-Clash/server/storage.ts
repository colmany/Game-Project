import { db } from "./db";
import {
  users, profiles, categories, games, weeks, gameSessions, brands, discountCodes, userRewards,
  type User, type InsertUser, type Profile, type Game, type Week, type GameSession, type UserReward, type Category,
  type LeaderboardEntry
} from "@shared/schema";
import { eq, and, desc, sql, sum, gt, lt } from "drizzle-orm";
import session from "express-session";
import connectPg from "connect-pg-simple";
import { pool } from "./db";

const PostgresSessionStore = connectPg(session);

export interface IStorage {
  // Auth & Users
  getUser(id: number): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser & { displayName: string }): Promise<User>;
  updateProfile(userId: number, updates: Partial<Profile>): Promise<Profile>;
  updateSubscription(userId: number, active: boolean): Promise<User>;

  // Categories
  getCategories(): Promise<Category[]>;
  
  // Games & Weeks
  getGames(): Promise<Game[]>;
  getGame(id: number): Promise<Game | undefined>;
  getCurrentWeek(): Promise<Week | undefined>;
  createGameSession(session: { userId: number; gameId: number; weekId: number; sessionId: string; score: number }): Promise<void>;
  validateGameSession(sessionId: string): Promise<boolean>; // Check if session used
  
  // Leaderboards
  getLeaderboard(categorySlug: string, weekId: number): Promise<LeaderboardEntry[]>;
  getUserRank(userId: number, categorySlug: string, weekId: number): Promise<{ rank: number; totalScore: number } | undefined>;

  // Rewards
  getUserRewards(userId: number): Promise<any[]>;
  
  // Seeding/Admin
  seedInitialData(): Promise<void>;
  
  sessionStore: session.Store;
}

export class DatabaseStorage implements IStorage {
  sessionStore: session.Store;

  constructor() {
    this.sessionStore = new PostgresSessionStore({
      pool,
      createTableIfMissing: true,
    });
  }

  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.email, email));
    return user;
  }

  async createUser(insertUser: InsertUser & { displayName: string }): Promise<User> {
    return await db.transaction(async (tx) => {
      const [user] = await tx.insert(users).values({
        email: insertUser.email,
        password: insertUser.password,
        subscriptionStatus: "inactive"
      }).returning();

      await tx.insert(profiles).values({
        userId: user.id,
        displayName: insertUser.displayName,
      });

      return user;
    });
  }

  async updateProfile(userId: number, updates: Partial<Profile>): Promise<Profile> {
    const [profile] = await db.update(profiles)
      .set(updates)
      .where(eq(profiles.userId, userId))
      .returning();
    return profile;
  }
  
  async updateSubscription(userId: number, active: boolean): Promise<User> {
     const [user] = await db.update(users)
      .set({ subscriptionStatus: active ? "active" : "inactive" })
      .where(eq(users.id, userId))
      .returning();
    return user;
  }

  async getCategories(): Promise<Category[]> {
    return await db.select().from(categories);
  }

  async getGames(): Promise<Game[]> {
    return await db.select().from(games).where(eq(games.isActive, true));
  }

  async getGame(id: number): Promise<Game | undefined> {
    const [game] = await db.select().from(games).where(eq(games.id, id));
    return game;
  }

  async getCurrentWeek(): Promise<Week | undefined> {
    // Return active week or last created week
    const [week] = await db.select().from(weeks)
      .where(eq(weeks.isActive, true))
      .limit(1);
    
    if (!week) {
        // Fallback to most recent week if none active (for safety)
        const [lastWeek] = await db.select().from(weeks).orderBy(desc(weeks.id)).limit(1);
        return lastWeek;
    }
    return week;
  }

  async createGameSession(session: { userId: number; gameId: number; weekId: number; sessionId: string; score: number }): Promise<void> {
    await db.insert(gameSessions).values({
        ...session,
        finishedAt: new Date()
    });
  }
  
  async validateGameSession(sessionId: string): Promise<boolean> {
      // Check if this session ID has already been submitted
      const [existing] = await db.select().from(gameSessions).where(eq(gameSessions.sessionId, sessionId));
      return !!existing;
  }

  async getLeaderboard(categorySlug: string, weekId: number): Promise<LeaderboardEntry[]> {
    // 1. Get category ID
    const [category] = await db.select().from(categories).where(eq(categories.slug, categorySlug));
    if (!category) return [];

    // 2. Aggregate scores per user for this week
    // Simplified: Sum of all scores for games. 
    // Ideally: Max score per game per user, then sum those maxes.
    
    // Let's implement: Sum of max score per game type
    
    // Subquery to find max score per (user, game) for the current week
    const maxScores = db.select({
        userId: gameSessions.userId,
        gameId: gameSessions.gameId,
        maxScore: sql<number>`MAX(${gameSessions.score})`.as('max_score')
    })
    .from(gameSessions)
    .where(eq(gameSessions.weekId, weekId))
    .groupBy(gameSessions.userId, gameSessions.gameId)
    .as('max_scores');

    // Join with users and profiles and sum up the max scores
    const leaderboard = await db.select({
        userId: users.id,
        displayName: profiles.displayName,
        avatarUrl: profiles.avatarUrl,
        totalScore: sql<number>`SUM(${maxScores.maxScore})`.mapWith(Number),
        // rank will be calculated in application layer or via window function if supported
    })
    .from(maxScores)
    .innerJoin(users, eq(users.id, maxScores.userId))
    .innerJoin(profiles, eq(profiles.userId, users.id))
    // Filter users who have this category chosen? 
    // For MVP, allow global competition, but could filter by profile.chosenCategories containing categorySlug
    .groupBy(users.id, profiles.displayName, profiles.avatarUrl)
    .orderBy(desc(sql`SUM(${maxScores.maxScore})`))
    .limit(100);

    return leaderboard.map((entry, index) => ({
        ...entry,
        rank: index + 1
    }));
  }

  async getUserRank(userId: number, categorySlug: string, weekId: number): Promise<{ rank: number; totalScore: number } | undefined> {
    // Re-using the leaderboard logic is expensive but simple for MVP.
    // Optimization: Calculate single user score directly.
    const leaderboard = await this.getLeaderboard(categorySlug, weekId);
    return leaderboard.find(e => e.userId === userId);
  }

  async getUserRewards(userId: number): Promise<any[]> {
    return await db.query.userRewards.findMany({
        where: eq(userRewards.userId, userId),
        with: {
            discountCode: {
                with: {
                    brand: {
                        with: {
                            category: true
                        }
                    }
                }
            }
        },
        orderBy: desc(userRewards.assignedAt)
    });
  }

  async seedInitialData(): Promise<void> {
    const existingCats = await this.getCategories();
    if (existingCats.length === 0) {
        await db.insert(categories).values([
            { name: "Home", slug: "home" },
            { name: "Accessories", slug: "accessories" },
            { name: "Tech", slug: "tech" },
            { name: "Clothing", slug: "clothing" },
            { name: "Misc", slug: "misc" },
        ]);
        
        await db.insert(games).values([
            { title: "Tap Fly", description: "Keep flying!", type: "tap-fly", config: {} },
            { title: "Reaction Tap", description: "Test your reflexes", type: "reaction-tap", config: {} },
            { title: "Memory Tiles", description: "Remember the pattern", type: "memory-tiles", config: {} },
        ]);

        await db.insert(weeks).values([
            { startDate: new Date(), endDate: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000), weekNumber: 1, isActive: true }
        ]);
        
        // Seed Brands
        const cats = await db.select().from(categories);
        const homeCat = cats.find(c => c.slug === 'home');
        const techCat = cats.find(c => c.slug === 'tech');
        
        if (homeCat) {
             const [brand] = await db.insert(brands).values({ name: "CozyHome", categoryId: homeCat.id }).returning();
             await db.insert(discountCodes).values({ brandId: brand.id, code: "WELCOME20", description: "20% off your first order" });
        }
        if (techCat) {
             const [brand] = await db.insert(brands).values({ name: "TechGiant", categoryId: techCat.id }).returning();
             await db.insert(discountCodes).values({ brandId: brand.id, code: "TECH10", description: "10% off accessories" });
        }
    }
  }
}

export const storage = new DatabaseStorage();
