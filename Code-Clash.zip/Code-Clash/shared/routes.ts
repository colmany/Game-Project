import { z } from 'zod';
import { 
  insertUserSchema, 
  insertProfileSchema,
  users,
  profiles,
  categories,
  games,
  weeks,
  userRewards
} from './schema';

// ============================================
// SHARED ERROR SCHEMAS
// ============================================
export const errorSchemas = {
  validation: z.object({
    message: z.string(),
    field: z.string().optional(),
  }),
  notFound: z.object({
    message: z.string(),
  }),
  internal: z.object({
    message: z.string(),
  }),
  unauthorized: z.object({
    message: z.string(),
  }),
  forbidden: z.object({
    message: z.string(),
  }),
};

// ============================================
// API CONTRACT
// ============================================
export const api = {
  auth: {
    register: {
      method: 'POST' as const,
      path: '/api/register' as const,
      input: insertUserSchema.extend({
        displayName: z.string().min(2),
      }),
      responses: {
        201: z.custom<typeof users.$inferSelect>(),
        400: errorSchemas.validation,
      },
    },
    login: {
      method: 'POST' as const,
      path: '/api/login' as const,
      input: z.object({
        email: z.string().email(),
        password: z.string(),
      }),
      responses: {
        200: z.custom<typeof users.$inferSelect>(),
        401: errorSchemas.unauthorized,
      },
    },
    logout: {
      method: 'POST' as const,
      path: '/api/logout' as const,
      responses: {
        200: z.object({ message: z.string() }),
      },
    },
    me: {
      method: 'GET' as const,
      path: '/api/user' as const,
      responses: {
        200: z.custom<typeof users.$inferSelect & { profile: typeof profiles.$inferSelect }>(),
        401: errorSchemas.unauthorized,
      },
    },
  },
  profile: {
    update: {
      method: 'PATCH' as const,
      path: '/api/profile' as const,
      input: insertProfileSchema.partial().omit({ userId: true }),
      responses: {
        200: z.custom<typeof profiles.$inferSelect>(),
        401: errorSchemas.unauthorized,
      },
    },
    toggleSubscription: {
      method: 'POST' as const,
      path: '/api/profile/subscription' as const,
      input: z.object({ active: z.boolean() }),
      responses: {
        200: z.custom<typeof users.$inferSelect>(),
      }
    }
  },
  categories: {
    list: {
      method: 'GET' as const,
      path: '/api/categories' as const,
      responses: {
        200: z.array(z.custom<typeof categories.$inferSelect>()),
      },
    },
  },
  weeks: {
    current: {
      method: 'GET' as const,
      path: '/api/weeks/current' as const,
      responses: {
        200: z.custom<typeof weeks.$inferSelect>(),
      },
    },
  },
  games: {
    list: {
      method: 'GET' as const,
      path: '/api/games' as const,
      responses: {
        200: z.array(z.custom<typeof games.$inferSelect>()),
      },
    },
    start: {
      method: 'POST' as const,
      path: '/api/games/:id/start' as const,
      responses: {
        200: z.object({ sessionId: z.string(), config: z.unknown().optional() }),
        401: errorSchemas.unauthorized,
        403: errorSchemas.forbidden, // Subscription check
      },
    },
    submitScore: {
      method: 'POST' as const,
      path: '/api/games/:id/score' as const,
      input: z.object({
        score: z.number(),
        sessionId: z.string(),
      }),
      responses: {
        200: z.object({ message: z.string(), newHighScore: z.boolean() }),
        400: errorSchemas.validation, // Invalid session or anti-cheat
      },
    },
  },
  leaderboards: {
    get: {
      method: 'GET' as const,
      path: '/api/leaderboards/:categorySlug' as const,
      responses: {
        200: z.object({
          category: z.string(),
          entries: z.array(z.object({
            rank: z.number(),
            userId: z.number(),
            displayName: z.string(),
            avatarUrl: z.string().nullable(),
            totalScore: z.number(),
          })),
          userRank: z.object({
            rank: z.number(),
            totalScore: z.number(),
          }).optional(),
        }),
      },
    },
  },
  rewards: {
    list: {
      method: 'GET' as const,
      path: '/api/rewards' as const,
      responses: {
        200: z.array(z.custom<typeof userRewards.$inferSelect & { 
          discountCode: { 
            code: string, 
            description: string, 
            expiresAt: string | null,
            brand: { name: string, logoUrl: string | null } 
          } 
        }>()),
      },
    },
  },
};

export function buildUrl(path: string, params?: Record<string, string | number>): string {
  let url = path;
  if (params) {
    Object.entries(params).forEach(([key, value]) => {
      if (url.includes(`:${key}`)) {
        url = url.replace(`:${key}`, String(value));
      }
    });
  }
  return url;
}
