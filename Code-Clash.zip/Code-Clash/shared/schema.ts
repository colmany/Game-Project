import { pgTable, text, serial, integer, boolean, timestamp, jsonb } from "drizzle-orm/pg-core";
import { relations } from "drizzle-orm";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// === TABLE DEFINITIONS ===

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  email: text("email").notNull().unique(),
  password: text("password").notNull(), // Hashed
  subscriptionStatus: text("subscription_status").notNull().default("inactive"), // "active" | "inactive"
  subscriptionEndDate: timestamp("subscription_end_date"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const profiles = pgTable("profiles", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  displayName: text("display_name").notNull(),
  avatarUrl: text("avatar_url"),
  chosenCategories: jsonb("chosen_categories").$type<string[]>().default([]), // Array of category IDs or slugs
});

export const categories = pgTable("categories", {
  id: serial("id").primaryKey(),
  name: text("name").notNull().unique(), // home, accessories, tech, clothing, misc
  slug: text("slug").notNull().unique(),
});

export const weeks = pgTable("weeks", {
  id: serial("id").primaryKey(),
  startDate: timestamp("start_date").notNull(),
  endDate: timestamp("end_date").notNull(),
  isActive: boolean("is_active").default(false),
  weekNumber: integer("week_number").notNull(),
});

export const games = pgTable("games", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  description: text("description").notNull(),
  type: text("type").notNull(), // "tap-fly", "reaction-tap", "memory-tiles"
  config: jsonb("config"), // Game specific config
  isActive: boolean("is_active").default(true),
});

export const gameSessions = pgTable("game_sessions", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  gameId: integer("game_id").notNull().references(() => games.id),
  weekId: integer("week_id").notNull().references(() => weeks.id),
  score: integer("score").notNull(),
  sessionId: text("session_id").notNull(), // Anti-cheat token
  finishedAt: timestamp("finished_at").defaultNow(),
});

export const brands = pgTable("brands", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  logoUrl: text("logo_url"),
  categoryId: integer("category_id").notNull().references(() => categories.id),
});

export const discountCodes = pgTable("discount_codes", {
  id: serial("id").primaryKey(),
  brandId: integer("brand_id").notNull().references(() => brands.id),
  code: text("code").notNull(),
  description: text("description").notNull(),
  expiresAt: timestamp("expires_at"),
  isRedeemed: boolean("is_redeemed").default(false),
});

export const userRewards = pgTable("user_rewards", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  discountCodeId: integer("discount_code_id").notNull().references(() => discountCodes.id),
  weekId: integer("week_id").notNull().references(() => weeks.id),
  assignedAt: timestamp("assigned_at").defaultNow(),
  isViewed: boolean("is_viewed").default(false),
});

// === RELATIONS ===

export const usersRelations = relations(users, ({ one, many }) => ({
  profile: one(profiles, {
    fields: [users.id],
    references: [profiles.userId],
  }),
  gameSessions: many(gameSessions),
  rewards: many(userRewards),
}));

export const profilesRelations = relations(profiles, ({ one }) => ({
  user: one(users, {
    fields: [profiles.userId],
    references: [users.id],
  }),
}));

export const gameSessionsRelations = relations(gameSessions, ({ one }) => ({
  user: one(users, {
    fields: [gameSessions.userId],
    references: [users.id],
  }),
  game: one(games, {
    fields: [gameSessions.gameId],
    references: [games.id],
  }),
  week: one(weeks, {
    fields: [gameSessions.weekId],
    references: [weeks.id],
  }),
}));

export const rewardsRelations = relations(userRewards, ({ one }) => ({
  user: one(users, {
    fields: [userRewards.userId],
    references: [users.id],
  }),
  discountCode: one(discountCodes, {
    fields: [userRewards.discountCodeId],
    references: [discountCodes.id],
  }),
  week: one(weeks, {
    fields: [userRewards.weekId],
    references: [weeks.id],
  }),
}));

export const discountCodesRelations = relations(discountCodes, ({ one }) => ({
  brand: one(brands, {
    fields: [discountCodes.brandId],
    references: [brands.id],
  }),
}));

export const brandsRelations = relations(brands, ({ one, many }) => ({
  category: one(categories, {
    fields: [brands.categoryId],
    references: [categories.id],
  }),
  discountCodes: many(discountCodes),
}));

// === ZOD SCHEMAS ===

export const insertUserSchema = createInsertSchema(users).omit({ id: true, createdAt: true });
export const insertProfileSchema = createInsertSchema(profiles).omit({ id: true });
export const insertCategorySchema = createInsertSchema(categories).omit({ id: true });
export const insertGameSchema = createInsertSchema(games).omit({ id: true });
export const insertGameSessionSchema = createInsertSchema(gameSessions).omit({ id: true, finishedAt: true });
export const insertBrandSchema = createInsertSchema(brands).omit({ id: true });
export const insertDiscountCodeSchema = createInsertSchema(discountCodes).omit({ id: true });
export const insertUserRewardSchema = createInsertSchema(userRewards).omit({ id: true, assignedAt: true });

// === EXPLICIT API TYPES ===

export type User = typeof users.$inferSelect;
export type Profile = typeof profiles.$inferSelect;
export type Category = typeof categories.$inferSelect;
export type Game = typeof games.$inferSelect;
export type GameSession = typeof gameSessions.$inferSelect;
export type Week = typeof weeks.$inferSelect;
export type Brand = typeof brands.$inferSelect;
export type DiscountCode = typeof discountCodes.$inferSelect;
export type UserReward = typeof userRewards.$inferSelect;

export type CreateUserRequest = z.infer<typeof insertUserSchema>;
export type UpdateProfileRequest = Partial<z.infer<typeof insertProfileSchema>>;
export type SubmitScoreRequest = {
  score: number;
  sessionId: string;
};

export type LeaderboardEntry = {
  rank: number;
  userId: number;
  displayName: string;
  avatarUrl: string | null;
  totalScore: number;
};

export type RewardWithDetails = UserReward & {
  discountCode: DiscountCode & {
    brand: Brand & {
      category: Category;
    };
  };
};

export type GameStartResponse = {
  sessionId: string;
  config: unknown;
};
