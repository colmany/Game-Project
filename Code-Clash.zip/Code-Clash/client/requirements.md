## Packages
framer-motion | Essential for playful arcade animations and page transitions
clsx | Utility for constructing className strings conditionally
tailwind-merge | Utility for merging tailwind classes without conflicts

## Notes
Integration with backend API for games and rewards
Mobile-first design approach
Using Framer Motion for game interactions and UI transitions
