import { useRewards } from "@/hooks/use-data";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Copy, Gift, Clock, ExternalLink } from "lucide-react";
import BottomNav from "@/components/layout/BottomNav";
import { useToast } from "@/hooks/use-toast";

export default function Rewards() {
  const { data: rewards, isLoading } = useRewards();
  const { toast } = useToast();

  const copyCode = (code: string) => {
    navigator.clipboard.writeText(code);
    toast({
      title: "Copied!",
      description: "Code copied to clipboard.",
    });
  };

  return (
    <div className="min-h-screen bg-slate-50 pb-20 p-6">
      <h1 className="text-3xl font-display font-bold text-slate-900 mb-6">Your Loot</h1>

      {isLoading && <div className="text-center text-slate-400 mt-10">Loading rewards...</div>}

      <div className="space-y-4">
        {rewards?.map((reward) => (
          <div key={reward.id} className="bg-white rounded-2xl p-0 shadow-sm border border-slate-100 overflow-hidden flex flex-col sm:flex-row relative group hover:shadow-md transition-shadow">
            {/* Brand Section */}
            <div className="bg-gradient-to-br from-slate-100 to-slate-200 p-6 flex items-center justify-center sm:w-32 min-h-[100px]">
              {reward.discountCode.brand.logoUrl ? (
                <img src={reward.discountCode.brand.logoUrl} alt={reward.discountCode.brand.name} className="w-16 h-16 object-contain" />
              ) : (
                <Gift className="w-10 h-10 text-slate-400" />
              )}
            </div>

            {/* Content */}
            <div className="p-5 flex-1 flex flex-col justify-center">
              <div className="flex justify-between items-start mb-2">
                <div>
                  <h3 className="font-bold text-slate-800 text-lg">{reward.discountCode.brand.name}</h3>
                  <p className="text-slate-500 text-sm">{reward.discountCode.description}</p>
                </div>
              </div>

              <div className="mt-4 flex items-center gap-2">
                <div className="bg-slate-100 px-3 py-2 rounded-lg font-mono font-bold text-slate-700 flex-1 text-center border-dashed border-2 border-slate-200">
                  {reward.discountCode.code}
                </div>
                <Button size="icon" variant="outline" onClick={() => copyCode(reward.discountCode.code)}>
                  <Copy className="w-4 h-4" />
                </Button>
              </div>

              {reward.discountCode.expiresAt && (
                <div className="mt-3 flex items-center text-xs text-red-400 font-medium">
                  <Clock className="w-3 h-3 mr-1" />
                  Expires: {new Date(reward.discountCode.expiresAt).toLocaleDateString()}
                </div>
              )}
            </div>
            
            {/* New Badge */}
            {!reward.isViewed && (
              <div className="absolute top-3 right-3 w-3 h-3 bg-red-500 rounded-full animate-ping" />
            )}
          </div>
        ))}

        {rewards?.length === 0 && (
          <div className="text-center py-20 px-6">
            <div className="w-20 h-20 bg-slate-100 rounded-full flex items-center justify-center mx-auto mb-6">
              <Gift className="w-10 h-10 text-slate-300" />
            </div>
            <h3 className="text-xl font-bold text-slate-700 mb-2">No rewards yet</h3>
            <p className="text-slate-500">Play games to win discount codes from your favorite brands!</p>
            <Button className="mt-6" variant="outline" onClick={() => window.location.href='/games'}>
              Go to Arcade
            </Button>
          </div>
        )}
      </div>

      <BottomNav />
    </div>
  );
}
