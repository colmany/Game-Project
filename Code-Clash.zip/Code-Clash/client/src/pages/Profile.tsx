import { useAuth } from "@/hooks/use-auth";
import { useUpdateProfile } from "@/hooks/use-data";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Switch } from "@/components/ui/switch";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import BottomNav from "@/components/layout/BottomNav";
import { CreditCard, LogOut, Save, User as UserIcon } from "lucide-react";
import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { api } from "@shared/routes";

export default function Profile() {
  const { user, logoutMutation } = useAuth();
  const updateProfile = useUpdateProfile();
  const queryClient = useQueryClient();
  
  const [displayName, setDisplayName] = useState(user?.profile?.displayName || "");
  const [isEditing, setIsEditing] = useState(false);

  const toggleSubscription = useMutation({
    mutationFn: async (active: boolean) => {
      const res = await fetch(api.profile.toggleSubscription.path, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ active }),
      });
      if (!res.ok) throw new Error("Failed");
      return await res.json();
    },
    onSuccess: (data) => {
      queryClient.setQueryData(["/api/user"], data);
    }
  });

  const handleSave = () => {
    updateProfile.mutate({ displayName }, { onSuccess: () => setIsEditing(false) });
  };

  return (
    <div className="min-h-screen bg-slate-50 pb-20">
      <div className="bg-primary h-48 relative overflow-hidden">
        <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/cubes.png')] opacity-20"></div>
      </div>
      
      <div className="px-6 -mt-20 relative z-10">
        <div className="flex flex-col items-center mb-8">
          <Avatar className="w-32 h-32 border-4 border-white shadow-xl mb-4 bg-white">
            <AvatarImage src={user?.profile?.avatarUrl || undefined} />
            <AvatarFallback className="text-4xl font-bold bg-slate-100 text-slate-400">
              {user?.profile?.displayName?.[0] || "U"}
            </AvatarFallback>
          </Avatar>
          
          {isEditing ? (
            <div className="flex gap-2 w-full max-w-xs">
              <Input 
                value={displayName} 
                onChange={(e) => setDisplayName(e.target.value)} 
                className="bg-white"
              />
              <Button size="icon" onClick={handleSave} disabled={updateProfile.isPending}>
                <Save className="w-4 h-4" />
              </Button>
            </div>
          ) : (
            <div className="text-center relative group">
              <h2 className="text-2xl font-bold font-display text-slate-900">{user?.profile?.displayName}</h2>
              <p className="text-slate-500">{user?.email}</p>
              <Button 
                variant="ghost" 
                size="sm" 
                className="absolute -right-12 top-0 opacity-0 group-hover:opacity-100 transition-opacity"
                onClick={() => setIsEditing(true)}
              >
                Edit
              </Button>
            </div>
          )}
        </div>

        <div className="space-y-6 max-w-md mx-auto">
          {/* Subscription Card */}
          <div className="bg-white rounded-2xl p-6 shadow-sm border border-slate-100">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-indigo-100 flex items-center justify-center text-indigo-600">
                  <CreditCard className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-bold text-slate-800">Pro Subscription</h3>
                  <p className="text-sm text-slate-500">Access all games</p>
                </div>
              </div>
              <Switch 
                checked={user?.subscriptionStatus === "active"}
                onCheckedChange={(checked) => toggleSubscription.mutate(checked)}
              />
            </div>
            <p className="text-xs text-slate-400">
              {user?.subscriptionStatus === "active" 
                ? "Your subscription is active. Enjoy premium access!" 
                : "Subscribe to unlock exclusive games and rewards."}
            </p>
          </div>

          {/* Preferences */}
          <div className="bg-white rounded-2xl p-6 shadow-sm border border-slate-100">
            <h3 className="font-bold text-slate-800 mb-4 flex items-center gap-2">
              <UserIcon className="w-5 h-5 text-primary" /> Preferences
            </h3>
            <div className="space-y-4">
               <div>
                 <label className="text-sm font-medium text-slate-700 mb-2 block">Interests</label>
                 <div className="flex flex-wrap gap-2">
                   {user?.profile?.chosenCategories?.map((cat) => (
                     <span key={cat} className="px-3 py-1 bg-slate-100 rounded-full text-xs font-bold text-slate-600 capitalize">
                       {cat}
                     </span>
                   ))}
                   <Button variant="outline" size="sm" className="h-6 text-xs rounded-full" onClick={() => window.location.href = "/onboarding"}>
                     Edit
                   </Button>
                 </div>
               </div>
            </div>
          </div>

          <Button 
            variant="destructive" 
            className="w-full" 
            onClick={() => logoutMutation.mutate()}
          >
            <LogOut className="w-4 h-4 mr-2" /> Logout
          </Button>
        </div>
      </div>
      
      <BottomNav />
    </div>
  );
}
