import { useState } from "react";
import { useCategories, useUpdateProfile } from "@/hooks/use-data";
import { Button } from "@/components/ui/button";
import { useLocation } from "wouter";
import { Check, Loader2 } from "lucide-react";
import { cn } from "@/lib/utils";

export default function Onboarding() {
  const { data: categories, isLoading } = useCategories();
  const updateProfile = useUpdateProfile();
  const [, setLocation] = useLocation();
  const [selected, setSelected] = useState<string[]>([]);

  if (isLoading) {
    return <div className="min-h-screen flex items-center justify-center"><Loader2 className="animate-spin text-primary w-8 h-8" /></div>;
  }

  const toggleCategory = (slug: string) => {
    setSelected(prev => 
      prev.includes(slug) 
        ? prev.filter(s => s !== slug) 
        : [...prev, slug]
    );
  };

  const handleFinish = () => {
    updateProfile.mutate(
      { chosenCategories: selected },
      { onSuccess: () => setLocation("/") }
    );
  };

  const categoryColors: Record<string, string> = {
    home: "bg-blue-100 border-blue-300 text-blue-800",
    tech: "bg-purple-100 border-purple-300 text-purple-800",
    clothing: "bg-pink-100 border-pink-300 text-pink-800",
    accessories: "bg-yellow-100 border-yellow-300 text-yellow-800",
    misc: "bg-green-100 border-green-300 text-green-800",
  };

  return (
    <div className="min-h-screen bg-background p-6 flex flex-col max-w-md mx-auto">
      <div className="flex-1">
        <h1 className="text-3xl font-display font-bold mb-2">Pick Your Interests</h1>
        <p className="text-muted-foreground mb-8">We'll show you rewards based on what you like.</p>

        <div className="grid grid-cols-2 gap-4">
          {categories?.map((cat) => {
            const isSelected = selected.includes(cat.slug);
            return (
              <button
                key={cat.id}
                onClick={() => toggleCategory(cat.slug)}
                className={cn(
                  "p-4 rounded-xl border-2 transition-all duration-200 text-left relative overflow-hidden",
                  isSelected ? "ring-2 ring-primary ring-offset-2" : "opacity-70 hover:opacity-100",
                  categoryColors[cat.slug] || "bg-gray-100"
                )}
              >
                <span className="font-bold text-lg capitalize">{cat.name}</span>
                {isSelected && (
                  <div className="absolute top-2 right-2 bg-primary rounded-full p-1">
                    <Check className="w-3 h-3 text-white" />
                  </div>
                )}
              </button>
            );
          })}
        </div>
      </div>

      <div className="pt-6">
        <Button 
          className="w-full h-12 text-lg font-bold"
          onClick={handleFinish}
          disabled={selected.length === 0 || updateProfile.isPending}
        >
          {updateProfile.isPending ? "Saving..." : "Start Playing"}
        </Button>
      </div>
    </div>
  );
}
