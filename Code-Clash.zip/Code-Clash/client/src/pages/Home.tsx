import { useCurrentWeek, useRewards } from "@/hooks/use-data";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { Gift, Zap, ArrowRight, Star } from "lucide-react";
import BottomNav from "@/components/layout/BottomNav";
import { useAuth } from "@/hooks/use-auth";

export default function Home() {
  const { user } = useAuth();
  const { data: week } = useCurrentWeek();
  const { data: rewards } = useRewards();

  // Filter rewards not viewed
  const newRewardsCount = rewards?.filter(r => !r.isViewed).length || 0;

  return (
    <div className="min-h-screen bg-background pb-20 font-body">
      {/* Header */}
      <header className="bg-primary px-6 pt-12 pb-20 rounded-b-[2.5rem] shadow-xl relative overflow-hidden">
        <div className="absolute top-0 left-0 w-full h-full bg-[url('https://www.transparenttextures.com/patterns/cubes.png')] opacity-20"></div>
        <div className="relative z-10">
          <div className="flex justify-between items-center mb-6">
            <div>
              <p className="text-primary-foreground/80 font-medium">Welcome back,</p>
              <h1 className="text-3xl font-display font-bold text-white tracking-wide">
                {user?.profile?.displayName}
              </h1>
            </div>
            <div className="w-12 h-12 bg-white/20 backdrop-blur-md rounded-full flex items-center justify-center border-2 border-white/30">
              <span className="text-2xl">😎</span>
            </div>
          </div>

          <div className="bg-white/10 backdrop-blur-sm rounded-2xl p-4 border border-white/20">
            <div className="flex justify-between items-center text-white mb-2">
              <span className="text-sm font-medium uppercase tracking-wider opacity-80">Current Week</span>
              <span className="font-display font-bold text-lg">#{week?.weekNumber || 1}</span>
            </div>
            <div className="w-full bg-black/20 rounded-full h-3 mb-2">
              <div className="bg-accent h-full rounded-full w-[60%] shadow-[0_0_10px_rgba(255,105,180,0.5)]"></div>
            </div>
            <p className="text-xs text-white/60 text-right">3 days left</p>
          </div>
        </div>
      </header>

      <main className="px-6 -mt-12 relative z-20 space-y-6">
        {/* Play Card */}
        <div className="arcade-card bg-white rounded-3xl p-6 relative overflow-hidden group">
          <div className="absolute right-[-20px] top-[-20px] bg-yellow-100 w-32 h-32 rounded-full opacity-50 group-hover:scale-150 transition-transform duration-500"></div>
          <div className="relative z-10">
            <div className="w-12 h-12 bg-yellow-400 rounded-xl flex items-center justify-center mb-4 shadow-lg rotate-3">
              <Zap className="text-white w-7 h-7 fill-current" />
            </div>
            <h2 className="text-2xl font-display font-bold text-slate-800 mb-2">Ready to Play?</h2>
            <p className="text-slate-500 mb-6">Compete in this week's games to win exclusive discounts.</p>
            <Link href="/games">
              <Button className="w-full h-12 text-lg font-bold bg-slate-900 hover:bg-slate-800 arcade-button">
                Start Playing <ArrowRight className="ml-2 w-5 h-5" />
              </Button>
            </Link>
          </div>
        </div>

        {/* Quick Stats Grid */}
        <div className="grid grid-cols-2 gap-4">
          <Link href="/rewards">
            <Card className="p-4 border-none shadow-lg bg-gradient-to-br from-pink-50 to-white hover:scale-105 transition-transform">
              <Gift className="w-8 h-8 text-accent mb-2" />
              <div className="font-display font-bold text-2xl text-slate-800">{newRewardsCount}</div>
              <div className="text-sm text-slate-500">New Rewards</div>
            </Card>
          </Link>
          <Link href="/leaderboard">
            <Card className="p-4 border-none shadow-lg bg-gradient-to-br from-blue-50 to-white hover:scale-105 transition-transform">
              <Star className="w-8 h-8 text-yellow-500 mb-2 fill-current" />
              <div className="font-display font-bold text-2xl text-slate-800">#42</div>
              <div className="text-sm text-slate-500">Your Rank</div>
            </Card>
          </Link>
        </div>

        {/* Featured Section */}
        <div>
          <h3 className="text-lg font-bold font-display text-slate-800 mb-4 flex items-center">
            <span className="w-2 h-8 bg-primary rounded-full mr-3"></span>
            Trending Categories
          </h3>
          <div className="space-y-3">
            {['Tech', 'Accessories', 'Gaming'].map((cat, i) => (
              <div key={i} className="flex items-center p-3 bg-white rounded-xl shadow-sm border border-slate-100">
                <div className={`w-10 h-10 rounded-lg mr-4 flex items-center justify-center font-bold text-white
                  ${i === 0 ? 'bg-purple-500' : i === 1 ? 'bg-orange-500' : 'bg-blue-500'}
                `}>
                  {cat[0]}
                </div>
                <div className="flex-1">
                  <div className="font-bold text-slate-700">{cat}</div>
                  <div className="text-xs text-slate-400">12 rewards available</div>
                </div>
                <ArrowRight className="w-4 h-4 text-slate-300" />
              </div>
            ))}
          </div>
        </div>
      </main>

      <BottomNav />
    </div>
  );
}
