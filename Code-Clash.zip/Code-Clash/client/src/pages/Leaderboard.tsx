import { useState } from "react";
import { useLeaderboard, useCategories } from "@/hooks/use-data";
import { useAuth } from "@/hooks/use-auth";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import BottomNav from "@/components/layout/BottomNav";
import { Crown } from "lucide-react";

export default function Leaderboard() {
  const { user } = useAuth();
  const { data: categories } = useCategories();
  const [category, setCategory] = useState<string>("home"); // Default category slug
  const { data: leaderboard } = useLeaderboard(category);

  return (
    <div className="min-h-screen bg-slate-50 pb-20 p-6">
      <h1 className="text-3xl font-display font-bold text-slate-900 mb-6">Leaderboard</h1>

      {/* Category Selector */}
      <div className="mb-8">
        <Select value={category} onValueChange={setCategory}>
          <SelectTrigger className="w-full h-12 bg-white border-2 border-slate-200 rounded-xl font-bold text-slate-700">
            <SelectValue placeholder="Select Category" />
          </SelectTrigger>
          <SelectContent>
            {categories?.map((cat) => (
              <SelectItem key={cat.id} value={cat.slug} className="font-medium">
                {cat.name}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      {/* Top 3 Podium (Visual only if we have data) */}
      {leaderboard && leaderboard.entries.length >= 3 && (
        <div className="flex justify-center items-end gap-4 mb-10 h-48">
          {/* 2nd Place */}
          <div className="flex flex-col items-center w-24">
            <Avatar className="w-16 h-16 border-4 border-slate-300 mb-2">
              <AvatarImage src={leaderboard.entries[1].avatarUrl || undefined} />
              <AvatarFallback className="bg-slate-200 text-slate-500 font-bold">{leaderboard.entries[1].displayName[0]}</AvatarFallback>
            </Avatar>
            <div className="bg-slate-300 w-full h-24 rounded-t-lg flex items-center justify-center font-bold text-slate-600 shadow-lg relative">
              <span className="text-2xl">2</span>
            </div>
            <p className="text-xs font-bold mt-2 truncate w-full text-center">{leaderboard.entries[1].displayName}</p>
            <p className="text-xs text-slate-500">{leaderboard.entries[1].totalScore}</p>
          </div>
          
          {/* 1st Place */}
          <div className="flex flex-col items-center w-28 z-10">
            <Crown className="text-yellow-500 w-10 h-10 mb-[-10px] z-20 animate-bounce" fill="currentColor" />
            <Avatar className="w-20 h-20 border-4 border-yellow-400 mb-2">
              <AvatarImage src={leaderboard.entries[0].avatarUrl || undefined} />
              <AvatarFallback className="bg-yellow-100 text-yellow-600 font-bold">{leaderboard.entries[0].displayName[0]}</AvatarFallback>
            </Avatar>
            <div className="bg-yellow-400 w-full h-32 rounded-t-lg flex items-center justify-center font-bold text-white shadow-xl relative">
              <span className="text-4xl text-yellow-700/50">1</span>
            </div>
            <p className="text-sm font-bold mt-2 truncate w-full text-center text-yellow-700">{leaderboard.entries[0].displayName}</p>
            <p className="text-xs font-bold text-yellow-600">{leaderboard.entries[0].totalScore}</p>
          </div>

          {/* 3rd Place */}
          <div className="flex flex-col items-center w-24">
            <Avatar className="w-16 h-16 border-4 border-orange-300 mb-2">
              <AvatarImage src={leaderboard.entries[2].avatarUrl || undefined} />
              <AvatarFallback className="bg-orange-100 text-orange-500 font-bold">{leaderboard.entries[2].displayName[0]}</AvatarFallback>
            </Avatar>
            <div className="bg-orange-300 w-full h-16 rounded-t-lg flex items-center justify-center font-bold text-orange-800 shadow-lg relative">
              <span className="text-2xl">3</span>
            </div>
            <p className="text-xs font-bold mt-2 truncate w-full text-center">{leaderboard.entries[2].displayName}</p>
            <p className="text-xs text-slate-500">{leaderboard.entries[2].totalScore}</p>
          </div>
        </div>
      )}

      {/* List */}
      <div className="bg-white rounded-3xl shadow-sm border border-slate-100 overflow-hidden">
        {leaderboard?.entries.slice(3).map((entry, index) => (
          <div 
            key={entry.userId} 
            className={`flex items-center p-4 border-b border-slate-100 last:border-0 
              ${entry.userId === user?.id ? 'bg-blue-50' : ''}`}
          >
            <span className="w-8 font-bold text-slate-400 font-display">{index + 4}</span>
            <Avatar className="w-10 h-10 mr-3 border border-slate-100">
              <AvatarImage src={entry.avatarUrl || undefined} />
              <AvatarFallback className="bg-slate-100 text-slate-500">{entry.displayName[0]}</AvatarFallback>
            </Avatar>
            <div className="flex-1">
              <div className="font-bold text-slate-800">{entry.displayName}</div>
            </div>
            <div className="font-display font-bold text-primary">{entry.totalScore}</div>
          </div>
        ))}

        {leaderboard?.entries.length === 0 && (
          <div className="p-8 text-center text-slate-500">No scores yet. Be the first!</div>
        )}
      </div>

      {/* User Rank Sticky */}
      {leaderboard?.userRank && (
        <div className="fixed bottom-20 left-4 right-4 bg-slate-900 text-white p-4 rounded-xl flex items-center justify-between shadow-2xl z-30">
          <div className="flex items-center">
            <span className="font-display font-bold text-2xl mr-4 text-primary">#{leaderboard.userRank.rank}</span>
            <span className="font-medium">Your Ranking</span>
          </div>
          <span className="font-display font-bold">{leaderboard.userRank.totalScore} pts</span>
        </div>
      )}

      <BottomNav />
    </div>
  );
}
