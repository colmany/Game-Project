import { useState } from "react";
import { useGames, useStartGame, useSubmitScore } from "@/hooks/use-games";
import { useAuth } from "@/hooks/use-auth";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Lock, Play, Trophy } from "lucide-react";
import BottomNav from "@/components/layout/BottomNav";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";

// Game Components
import TapFly from "@/components/games/TapFly";
import ReactionTap from "@/components/games/ReactionTap";
import MemoryTiles from "@/components/games/MemoryTiles";

const GameComponentMap: Record<string, any> = {
  "tap-fly": TapFly,
  "reaction-tap": ReactionTap,
  "memory-tiles": MemoryTiles,
};

export default function Games() {
  const { data: games } = useGames();
  const { user } = useAuth();
  
  const [activeGameId, setActiveGameId] = useState<number | null>(null);
  const [sessionId, setSessionId] = useState<string | null>(null);
  const [showSubModal, setShowSubModal] = useState(false);

  const startGameMutation = useStartGame(activeGameId || 0);
  const submitScoreMutation = useSubmitScore(activeGameId || 0);

  const handlePlayClick = (game: any) => {
    if (user?.subscriptionStatus !== "active") {
      setShowSubModal(true);
      return;
    }

    setActiveGameId(game.id);
    startGameMutation.mutate(undefined, {
      onSuccess: (data) => {
        setSessionId(data.sessionId);
      }
    });
  };

  const handleGameOver = (score: number) => {
    if (activeGameId && sessionId) {
      submitScoreMutation.mutate({ score, sessionId });
    }
    setActiveGameId(null);
    setSessionId(null);
  };

  // If a game is active, render the overlay
  if (activeGameId && sessionId) {
    const game = games?.find(g => g.id === activeGameId);
    const GameComponent = GameComponentMap[game?.type || ""];
    
    if (GameComponent) {
      return (
        <GameComponent 
          isActive={true} 
          onGameOver={handleGameOver} 
        />
      );
    }
  }

  return (
    <div className="min-h-screen bg-slate-50 pb-20 p-6">
      <h1 className="text-4xl font-display font-bold text-slate-900 mb-2">Arcade</h1>
      <p className="text-slate-500 mb-8">Play to climb the leaderboards.</p>

      <div className="grid gap-6">
        {games?.map((game) => (
          <div key={game.id} className="arcade-card bg-white rounded-3xl p-6 relative overflow-hidden group">
            <div className={`absolute top-0 right-0 w-24 h-24 rounded-bl-full opacity-10 transition-colors
              ${game.type === 'tap-fly' ? 'bg-blue-500' : game.type === 'reaction-tap' ? 'bg-green-500' : 'bg-purple-500'}
            `}></div>
            
            <div className="relative z-10">
              <div className="flex justify-between items-start mb-4">
                <div className={`w-14 h-14 rounded-2xl flex items-center justify-center shadow-lg
                  ${game.type === 'tap-fly' ? 'bg-blue-500' : game.type === 'reaction-tap' ? 'bg-green-500' : 'bg-purple-500'}
                `}>
                  <Trophy className="text-white w-8 h-8" />
                </div>
                {user?.subscriptionStatus !== "active" && (
                  <div className="bg-slate-100 p-2 rounded-full">
                    <Lock className="w-5 h-5 text-slate-400" />
                  </div>
                )}
              </div>
              
              <h3 className="text-2xl font-display font-bold text-slate-800 mb-2">{game.title}</h3>
              <p className="text-slate-500 mb-6 line-clamp-2">{game.description}</p>
              
              <Button 
                onClick={() => handlePlayClick(game)}
                className="w-full bg-slate-900 text-white hover:bg-slate-800 arcade-button h-12 font-bold"
              >
                <Play className="w-5 h-5 mr-2 fill-current" /> Play Now
              </Button>
            </div>
          </div>
        ))}
      </div>

      <Dialog open={showSubModal} onOpenChange={setShowSubModal}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="text-2xl font-display text-center">Unlock the Arcade 🔓</DialogTitle>
            <DialogDescription className="text-center pt-2">
              Subscribe to access all premium games and win real rewards.
            </DialogDescription>
          </DialogHeader>
          <div className="flex flex-col gap-4 py-4">
            <div className="p-4 bg-yellow-50 border border-yellow-200 rounded-xl flex items-center">
              <div className="w-10 h-10 bg-yellow-400 rounded-full flex items-center justify-center text-white font-bold mr-4">$5</div>
              <div>
                <p className="font-bold text-slate-800">Weekly Pass</p>
                <p className="text-xs text-slate-500">Cancel anytime</p>
              </div>
            </div>
            <Button className="w-full h-12 text-lg" onClick={() => window.location.href = '/profile'}>
              Go to Profile to Subscribe
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      <BottomNav />
    </div>
  );
}
