import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api, buildUrl } from "@shared/routes";
import { useToast } from "./use-toast";

// Categories
export function useCategories() {
  return useQuery({
    queryKey: [api.categories.list.path],
    queryFn: async () => {
      const res = await fetch(api.categories.list.path);
      if (!res.ok) throw new Error("Failed to fetch categories");
      return await res.json();
    },
  });
}

// Weeks
export function useCurrentWeek() {
  return useQuery({
    queryKey: [api.weeks.current.path],
    queryFn: async () => {
      const res = await fetch(api.weeks.current.path);
      if (!res.ok) throw new Error("Failed to fetch current week");
      return await res.json();
    },
  });
}

// Leaderboards
export function useLeaderboard(categorySlug: string) {
  return useQuery({
    queryKey: [api.leaderboards.get.path, categorySlug],
    queryFn: async () => {
      const url = buildUrl(api.leaderboards.get.path, { categorySlug });
      const res = await fetch(url);
      if (!res.ok) throw new Error("Failed to fetch leaderboard");
      return await res.json();
    },
    enabled: !!categorySlug,
  });
}

// Rewards
export function useRewards() {
  return useQuery({
    queryKey: [api.rewards.list.path],
    queryFn: async () => {
      const res = await fetch(api.rewards.list.path);
      if (!res.ok) throw new Error("Failed to fetch rewards");
      return await res.json();
    },
  });
}

// Profile
export function useUpdateProfile() {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  return useMutation({
    mutationFn: async (updates: any) => {
      const res = await fetch(api.profile.update.path, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(updates),
      });
      if (!res.ok) throw new Error("Failed to update profile");
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/user"] });
      toast({ title: "Profile Updated", description: "Your changes have been saved." });
    },
  });
}
