import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api, buildUrl } from "@shared/routes";
import { useToast } from "@/hooks/use-toast";

export function useGames() {
  return useQuery({
    queryKey: [api.games.list.path],
    queryFn: async () => {
      const res = await fetch(api.games.list.path);
      if (!res.ok) throw new Error("Failed to fetch games");
      return await res.json();
    },
  });
}

export function useStartGame(gameId: number) {
  return useMutation({
    mutationFn: async () => {
      const url = buildUrl(api.games.start.path, { id: gameId });
      const res = await fetch(url, { method: "POST" });
      if (!res.ok) {
        const error = await res.json();
        throw new Error(error.message || "Failed to start game");
      }
      return await res.json(); // returns { sessionId, config }
    },
  });
}

export function useSubmitScore(gameId: number) {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  return useMutation({
    mutationFn: async (data: { score: number; sessionId: string }) => {
      const url = buildUrl(api.games.submitScore.path, { id: gameId });
      const res = await fetch(url, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });
      if (!res.ok) throw new Error("Failed to submit score");
      return await res.json();
    },
    onSuccess: (data) => {
      if (data.newHighScore) {
        toast({
          title: "NEW HIGH SCORE! 🏆",
          description: "You're crushing it! Check the leaderboard.",
          className: "bg-yellow-100 border-yellow-400 text-yellow-900",
        });
      } else {
        toast({
          title: "Score Submitted",
          description: "Keep playing to improve your rank!",
        });
      }
      queryClient.invalidateQueries({ queryKey: [api.leaderboards.get.path] });
    },
  });
}
