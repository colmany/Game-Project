import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { motion } from "framer-motion";

interface MemoryTilesProps {
  onGameOver: (score: number) => void;
  isActive: boolean;
}

export default function MemoryTiles({ onGameOver, isActive }: MemoryTilesProps) {
  const [sequence, setSequence] = useState<number[]>([]);
  const [userSequence, setUserSequence] = useState<number[]>([]);
  const [isPlayingSequence, setIsPlayingSequence] = useState(false);
  const [level, setLevel] = useState(1);
  const [activeTile, setActiveTile] = useState<number | null>(null);

  // Grid of 9 tiles
  const tiles = Array.from({ length: 9 }, (_, i) => i);

  useEffect(() => {
    if (isActive) {
      startLevel(1);
    }
  }, [isActive]);

  const startLevel = async (lvl: number) => {
    setLevel(lvl);
    setUserSequence([]);
    const newSeq = Array.from({ length: lvl }, () => Math.floor(Math.random() * 9));
    setSequence(newSeq);
    playSequence(newSeq);
  };

  const playSequence = async (seq: number[]) => {
    setIsPlayingSequence(true);
    // Initial delay
    await new Promise(r => setTimeout(r, 500));
    
    for (const tileIndex of seq) {
      setActiveTile(tileIndex);
      await new Promise(r => setTimeout(r, 600)); // Light up duration
      setActiveTile(null);
      await new Promise(r => setTimeout(r, 200)); // Gap
    }
    setIsPlayingSequence(false);
  };

  const handleTileClick = (index: number) => {
    if (isPlayingSequence) return;

    const newUserSequence = [...userSequence, index];
    setUserSequence(newUserSequence);

    // Flash the clicked tile briefly
    setActiveTile(index);
    setTimeout(() => setActiveTile(null), 200);

    // Check correctness
    const currentIndex = newUserSequence.length - 1;
    if (newUserSequence[currentIndex] !== sequence[currentIndex]) {
      // Wrong move
      onGameOver((level - 1) * 100); // Score based on completed levels
    } else if (newUserSequence.length === sequence.length) {
      // Completed level
      setTimeout(() => startLevel(level + 1), 1000);
    }
  };

  if (!isActive) return null;

  return (
    <div className="fixed inset-0 z-50 bg-slate-900 flex flex-col items-center justify-center p-4">
      <div className="text-center mb-8">
        <h2 className="text-3xl font-display text-white mb-2">Level {level}</h2>
        <p className="text-slate-400">Watch the pattern, then repeat it.</p>
      </div>

      <div className="grid grid-cols-3 gap-4 max-w-sm w-full aspect-square">
        {tiles.map((i) => (
          <motion.button
            key={i}
            whileTap={{ scale: 0.95 }}
            onClick={() => handleTileClick(i)}
            className={`
              rounded-xl shadow-lg transition-all duration-200
              ${activeTile === i 
                ? "bg-primary shadow-[0_0_30px_rgba(168,85,247,0.6)] border-2 border-white" 
                : "bg-slate-800 border-2 border-slate-700 hover:border-slate-500"}
            `}
          />
        ))}
      </div>

      <Button 
        variant="destructive" 
        className="mt-12 w-full max-w-xs"
        onClick={() => onGameOver((level - 1) * 100)}
      >
        Quit Game
      </Button>
    </div>
  );
}
