import { useState, useRef, useEffect } from "react";
import { Button } from "@/components/ui/button";

interface ReactionTapProps {
  onGameOver: (score: number) => void;
  isActive: boolean;
}

type State = "waiting" | "ready" | "go" | "clicked";

export default function ReactionTap({ onGameOver, isActive }: ReactionTapProps) {
  const [gameState, setGameState] = useState<State>("waiting");
  const [message, setMessage] = useState("Wait for Green...");
  const [startTime, setStartTime] = useState(0);
  const [reactionTime, setReactionTime] = useState(0);
  const timeoutRef = useRef<NodeJS.Timeout>();

  useEffect(() => {
    if (isActive) {
      startRound();
    }
    return () => clearTimeout(timeoutRef.current);
  }, [isActive]);

  const startRound = () => {
    setGameState("waiting");
    setMessage("Wait for Green...");
    const delay = Math.random() * 3000 + 2000; // 2-5s
    timeoutRef.current = setTimeout(() => {
      setGameState("go");
      setMessage("TAP NOW!");
      setStartTime(Date.now());
    }, delay);
  };

  const handleClick = () => {
    if (gameState === "waiting") {
      clearTimeout(timeoutRef.current);
      setGameState("clicked");
      setMessage("Too Early!");
      setTimeout(() => onGameOver(0), 1000);
      return;
    }

    if (gameState === "go") {
      const time = Date.now() - startTime;
      setReactionTime(time);
      setGameState("clicked");
      setMessage(`${time}ms`);
      
      // Calculate score based on reaction time (lower is better)
      // Base score 1000, minus reaction time. Min 0.
      const score = Math.max(0, 1000 - time);
      setTimeout(() => onGameOver(score), 1500);
    }
  };

  const getBgColor = () => {
    switch (gameState) {
      case "waiting": return "bg-red-500";
      case "go": return "bg-green-500";
      case "clicked": return "bg-blue-500";
      default: return "bg-gray-800";
    }
  };

  if (!isActive) return null;

  return (
    <div 
      className={`fixed inset-0 z-50 flex flex-col items-center justify-center ${getBgColor()} transition-colors duration-200`}
      onClick={handleClick}
    >
      <h1 className="text-6xl font-black text-white font-display select-none animate-bounce">
        {message}
      </h1>
      <p className="text-white/70 mt-4 text-xl">Tap anywhere when screen turns green</p>
      
      <Button 
        variant="outline" 
        className="absolute bottom-10"
        onClick={(e) => {
          e.stopPropagation();
          onGameOver(0);
        }}
      >
        Quit
      </Button>
    </div>
  );
}
