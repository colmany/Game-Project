import { useEffect, useRef, useState } from "react";
import { Button } from "@/components/ui/button";

interface TapFlyProps {
  onGameOver: (score: number) => void;
  isActive: boolean;
}

export default function TapFly({ onGameOver, isActive }: TapFlyProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [score, setScore] = useState(0);
  const requestRef = useRef<number>();
  
  // Game state refs (to avoid closure staleness in loop)
  const birdY = useRef(200);
  const birdVelocity = useRef(0);
  const obstacles = useRef<{x: number, gapY: number}[]>([]);
  const gameActive = useRef(false);
  const scoreRef = useRef(0);

  const GRAVITY = 0.6;
  const JUMP = -8;
  const SPEED = 3;
  const GAP_SIZE = 150;
  const OBSTACLE_WIDTH = 50;

  const jump = () => {
    if (!gameActive.current) return;
    birdVelocity.current = JUMP;
  };

  useEffect(() => {
    if (!isActive) return;

    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    // Reset state
    birdY.current = canvas.height / 2;
    birdVelocity.current = 0;
    obstacles.current = [];
    scoreRef.current = 0;
    setScore(0);
    gameActive.current = true;

    // Initial obstacle
    obstacles.current.push({
      x: canvas.width,
      gapY: Math.random() * (canvas.height - GAP_SIZE - 100) + 50
    });

    const loop = () => {
      if (!gameActive.current) return;

      // Update physics
      birdVelocity.current += GRAVITY;
      birdY.current += birdVelocity.current;

      // Generate obstacles
      const lastObstacle = obstacles.current[obstacles.current.length - 1];
      if (canvas.width - lastObstacle.x > 250) {
        obstacles.current.push({
          x: canvas.width,
          gapY: Math.random() * (canvas.height - GAP_SIZE - 100) + 50
        });
      }

      // Move obstacles & collision
      obstacles.current.forEach(obs => {
        obs.x -= SPEED;

        // Collision detection
        // Bird: x=50, w=30, h=30
        const birdX = 50;
        const birdSize = 30;

        const hitTopPipe = 
          birdX + birdSize > obs.x && 
          birdX < obs.x + OBSTACLE_WIDTH && 
          birdY.current < obs.gapY;
          
        const hitBottomPipe = 
          birdX + birdSize > obs.x && 
          birdX < obs.x + OBSTACLE_WIDTH && 
          birdY.current + birdSize > obs.gapY + GAP_SIZE;

        const hitGround = birdY.current + birdSize > canvas.height;
        const hitCeiling = birdY.current < 0;

        if (hitTopPipe || hitBottomPipe || hitGround || hitCeiling) {
          gameActive.current = false;
          onGameOver(scoreRef.current);
        }

        // Score counting
        if (obs.x + OBSTACLE_WIDTH < birdX && !obs['passed' as keyof typeof obs]) {
          scoreRef.current += 1;
          setScore(scoreRef.current);
          // @ts-ignore - dynamic prop
          obs.passed = true;
        }
      });

      // Cleanup off-screen obstacles
      if (obstacles.current[0].x < -OBSTACLE_WIDTH) {
        obstacles.current.shift();
      }

      // Draw
      ctx.fillStyle = "#87CEEB"; // Sky
      ctx.fillRect(0, 0, canvas.width, canvas.height);

      // Draw Bird
      ctx.fillStyle = "#FFD700";
      ctx.beginPath();
      ctx.arc(65, birdY.current + 15, 15, 0, Math.PI * 2);
      ctx.fill();
      ctx.strokeStyle = "#000";
      ctx.lineWidth = 2;
      ctx.stroke();

      // Draw Obstacles
      ctx.fillStyle = "#228B22";
      obstacles.current.forEach(obs => {
        // Top pipe
        ctx.fillRect(obs.x, 0, OBSTACLE_WIDTH, obs.gapY);
        // Bottom pipe
        ctx.fillRect(obs.x, obs.gapY + GAP_SIZE, OBSTACLE_WIDTH, canvas.height - (obs.gapY + GAP_SIZE));
        
        // Pipe borders
        ctx.strokeRect(obs.x, 0, OBSTACLE_WIDTH, obs.gapY);
        ctx.strokeRect(obs.x, obs.gapY + GAP_SIZE, OBSTACLE_WIDTH, canvas.height - (obs.gapY + GAP_SIZE));
      });

      // Score
      ctx.fillStyle = "#FFF";
      ctx.font = "bold 40px Chakra Petch";
      ctx.strokeStyle = "#000";
      ctx.lineWidth = 4;
      ctx.strokeText(scoreRef.current.toString(), canvas.width / 2 - 10, 50);
      ctx.fillText(scoreRef.current.toString(), canvas.width / 2 - 10, 50);

      requestRef.current = requestAnimationFrame(loop);
    };

    requestRef.current = requestAnimationFrame(loop);

    return () => {
      if (requestRef.current) cancelAnimationFrame(requestRef.current);
    };
  }, [isActive]);

  return (
    <div className="relative w-full h-full flex flex-col items-center justify-center bg-black/80 fixed inset-0 z-50">
      <div className="relative">
        <canvas 
          ref={canvasRef} 
          width={400} 
          height={600} 
          onClick={jump}
          className="bg-sky-300 rounded-lg cursor-pointer shadow-2xl border-4 border-white"
        />
        <div className="absolute bottom-4 left-0 right-0 text-center pointer-events-none">
          <p className="text-white/80 font-display text-lg animate-pulse">Tap to Fly!</p>
        </div>
      </div>
      <Button 
        variant="destructive" 
        className="mt-4"
        onClick={() => onGameOver(score)}
      >
        Quit Game
      </Button>
    </div>
  );
}
